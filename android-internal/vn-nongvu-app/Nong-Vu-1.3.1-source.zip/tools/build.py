import pathlib,subprocess,zipfile,os
r=pathlib.Path(__file__).resolve().parents[1]
t=pathlib.Path(os.environ.get('ANDROID_BUILD_TOOLS','/workspace/scratch/a2c884d6b627/source-inspect/build-tools'))
api=pathlib.Path(os.environ.get('ANDROID_API_JAR','/workspace/scratch/92f9ab9bef76/android-api33.jar'))
def run(*a):subprocess.run(list(map(str,a)),check=True)
run('java','-jar',t/'ecj.jar','-8','-nowarn','-proc:none','-cp',api,'-d',r/'classes',*sorted((r/'src').rglob('*.java')))
with zipfile.ZipFile(r/'native.jar','w') as z:
 for p in (r/'classes').rglob('*.class'):z.write(p,p.relative_to(r/'classes'))
run('java','-cp',t/'r8.jar','com.android.tools.r8.D8','--min-api','26','--lib',api,'--output',r/'dex',r/'native.jar')
run('java','-jar',t/'apktool.jar','b',r,'-o',r/'unsigned.apk')
with zipfile.ZipFile(r/'unsigned.apk','a',compression=zipfile.ZIP_DEFLATED) as z:z.write(r/'dex/classes.dex','classes.dex')
run('python3',r/'tools/align_apk.py',r/'unsigned.apk',r/'aligned.apk')
run('python3',r/'tools/sign_apk.py',r/'aligned.apk',r.parent/'Nong-Vu-1.3.1.apk')
run('python3',r/'tools/verify_signature.py',r.parent/'Nong-Vu-1.3.1.apk')

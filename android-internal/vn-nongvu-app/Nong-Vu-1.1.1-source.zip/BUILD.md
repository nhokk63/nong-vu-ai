Nông Vụ 1.1.1 — native OTA repair

APK code 10101, bundled UI 11002; OTA 11003 requires APK 10101.
The file:///android_asset/index.html bootstrap retains the existing URL and storage keys, obtains a composed document via the native bridge, and replaces the current document. Android does not intercept android_asset requests, so the former interception implementation could not activate an OTA.

Run tools/build.py with ANDROID_BUILD_TOOLS and ANDROID_API_JAR configured. Supply the original private signing key and certificate privately in tools; NEVER generate a replacement key for installation over an existing app. Signing credentials are not included.

Validation: native compilation, APK v2 signature/alignment, same certificate as 1.1.0, document-composition tests, security tests, JS runtime tests, browser bootstrap with mocked bridge returning UI11003 and readiness ack. No physical-device or emulator installation test performed.

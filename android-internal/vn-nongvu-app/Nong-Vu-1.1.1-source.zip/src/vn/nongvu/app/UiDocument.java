package vn.nongvu.app;
public final class UiDocument {
 public static String compose(String html,String css,String js){
 String link="<link rel=\"stylesheet\" href=\"style.css\">",script="<script src=\"app.js\"></script>";
 if(!html.contains(link)||!html.contains(script))throw new IllegalArgumentException("Gói giao diện thiếu điểm nạp CSS/JS");
 if(css.toLowerCase(java.util.Locale.US).contains("</style")||js.toLowerCase(java.util.Locale.US).contains("</script"))throw new IllegalArgumentException("Nội dung giao diện không hợp lệ");
 return html.replace(link,"<style>"+css+"</style>").replace(script,"<script>"+js+"</script>");
 }
}

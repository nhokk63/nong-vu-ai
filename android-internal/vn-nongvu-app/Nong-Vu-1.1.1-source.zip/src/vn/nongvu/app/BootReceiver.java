package vn.nongvu.app;import android.content.*;public class BootReceiver extends BroadcastReceiver {public void onReceive(Context c,Intent i){Reminders.restore(c);}}

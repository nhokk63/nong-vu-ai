import vn.nongvu.app.UiDocument;import java.nio.file.*;
public class UiDocumentTest{
 public static void main(String[] args)throws Exception{
 String h=new String(Files.readAllBytes(Paths.get("assets/bundled.html")),"UTF-8"),c=new String(Files.readAllBytes(Paths.get("assets/style.css")),"UTF-8"),j=new String(Files.readAllBytes(Paths.get("assets/app.js")),"UTF-8");
 String base=UiDocument.compose(h,c,j),ota=UiDocument.compose(h,c,j.replace("NV_UI_BUILD=11002","NV_UI_BUILD=11003"));
 if(!base.contains("NV_UI_BUILD=11002")||!ota.contains("NV_UI_BUILD=11003")||ota.contains("src=\"app.js\"")||ota.contains("href=\"style.css\""))throw new AssertionError("Wrong bundle");
 boolean rejected=false;try{UiDocument.compose("broken",c,j);}catch(IllegalArgumentException e){rejected=true;}if(!rejected)throw new AssertionError("Invalid document accepted");
 String bootstrap=new String(Files.readAllBytes(Paths.get("assets/index.html")),"UTF-8");if(!bootstrap.contains("NongVuAndroid.document()")||!bootstrap.contains("document.write(html)"))throw new AssertionError();
 Files.write(Paths.get("composed-test.html"),ota.getBytes("UTF-8"));System.out.println("PASS: embedded/OTA document composition, exact readiness version, no external asset dependency, invalid bundle rejection, bootstrap bridge.");
 }
}

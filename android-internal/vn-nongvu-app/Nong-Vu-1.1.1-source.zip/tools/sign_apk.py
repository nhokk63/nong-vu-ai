#!/usr/bin/env python3
"""Offline APK Signature Scheme v2 RSA/SHA-256 signer. Keep signing-key.pem private."""
import sys,struct,hashlib,datetime,pathlib
from cryptography.hazmat.primitives.asymmetric import rsa,padding
from cryptography.hazmat.primitives import serialization,hashes
from cryptography import x509
from cryptography.x509.oid import NameOID
u32=lambda n:struct.pack('<I',n)
u64=lambda n:struct.pack('<Q',n)
lp=lambda b:u32(len(b))+b
root=pathlib.Path(__file__).parent
keyfile=root/'signing-key.pem';certfile=root/'signing-cert.der'
if keyfile.exists():
 key=serialization.load_pem_private_key(keyfile.read_bytes(),password=None);cert=certfile.read_bytes()
else:
 key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
 name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'Nong Vu Release')])
 crt=x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(datetime.datetime(2026,1,1)).not_valid_after(datetime.datetime(2056,1,1)).sign(key,hashes.SHA256())
 cert=crt.public_bytes(serialization.Encoding.DER);keyfile.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()));keyfile.chmod(0o600);certfile.write_bytes(cert)
b=pathlib.Path(sys.argv[1]).read_bytes();e=b.rfind(b'PK\x05\x06');assert e>=0 and e+22+struct.unpack_from('<H',b,e+20)[0]==len(b)
cd=struct.unpack_from('<I',b,e+16)[0]
chunks=[]
for section in [b[:cd],b[cd:e],b[e:]]:
 for i in range(0,len(section),1024*1024):
  block=section[i:i+1024*1024];chunks.append(hashlib.sha256(b'\xa5'+u32(len(block))+block).digest())
digest=hashlib.sha256(b'\x5a'+u32(len(chunks))+b''.join(chunks)).digest();alg=u32(0x0103)
signed=lp(lp(alg+lp(digest)))+lp(lp(cert))+lp(b'')
sig=key.sign(signed,padding.PKCS1v15(),hashes.SHA256())
pub=key.public_key().public_bytes(serialization.Encoding.DER,serialization.PublicFormat.SubjectPublicKeyInfo)
signer=lp(signed)+lp(lp(alg+lp(sig)))+lp(pub)
value=lp(lp(signer));pair=u64(4+len(value))+u32(0x7109871a)+value
size=len(pair)+24;block=u64(size)+pair+u64(size)+b'APK Sig Block 42'
eocd=bytearray(b[e:]);struct.pack_into('<I',eocd,16,cd+len(block))
output=b[:cd]+block+b[cd:e]+bytes(eocd)
pathlib.Path(sys.argv[2]).write_bytes(output)
key.public_key().verify(sig,signed,padding.PKCS1v15(),hashes.SHA256())
print('Signed v2:',sys.argv[2]);print('SHA256:',hashlib.sha256(output).hexdigest())

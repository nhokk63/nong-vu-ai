#!/usr/bin/env python3
"""Store Android resources uncompressed and align stored entries before signing."""
import sys,zipfile,struct
from pathlib import Path
src,dst=sys.argv[1:3]
assert Path(src).resolve()!=Path(dst).resolve()
with zipfile.ZipFile(src) as zin,zipfile.ZipFile(dst,'w') as zout:
 for item in zin.infolist():
  if item.filename.startswith('META-INF/'):continue
  info=zipfile.ZipInfo(item.filename,item.date_time)
  info.external_attr=item.external_attr
  info.compress_type=zipfile.ZIP_STORED if item.filename in ['resources.arsc','AndroidManifest.xml'] or item.compress_type==zipfile.ZIP_STORED else zipfile.ZIP_DEFLATED
  if info.compress_type==zipfile.ZIP_STORED:
   start=zout.fp.tell()+30+len(info.filename.encode('utf-8'))
   pad=(-start)%4
   if pad:info.extra=struct.pack('<HH',0xcafe,pad)+b'\0'*pad
  zout.writestr(info,zin.read(item.filename))
b=Path(dst).read_bytes()
with zipfile.ZipFile(dst) as z:
 for info in z.infolist():
  if info.compress_type!=zipfile.ZIP_STORED:continue
  n,e=struct.unpack_from('<HH',b,info.header_offset+26)
  assert (info.header_offset+30+n+e)%4==0,info.filename
 assert z.getinfo('resources.arsc').compress_type==zipfile.ZIP_STORED
print('Resources stored uncompressed; all stored entries aligned to 4 bytes.')

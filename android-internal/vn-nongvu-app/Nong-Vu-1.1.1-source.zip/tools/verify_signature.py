import struct,hashlib,sys,zipfile
from cryptography import x509
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import padding
b=open(sys.argv[1],'rb').read();e=b.rfind(b'PK\x05\x06');cd=struct.unpack_from('<I',b,e+16)[0]
assert b[cd-16:cd]==b'APK Sig Block 42'
size=struct.unpack_from('<Q',b,cd-24)[0];start=cd-size-8
assert struct.unpack_from('<Q',b,start)[0]==size
pairlen=struct.unpack_from('<Q',b,start+8)[0];assert struct.unpack_from('<I',b,start+16)[0]==0x7109871a
v=b[start+20:start+16+pairlen]
def take(data,off=0):
 n=struct.unpack_from('<I',data,off)[0];return data[off+4:off+4+n],off+4+n
signers,_=take(v);signer,_=take(signers);signed,off=take(signer);signatures,off=take(signer,off);pub,_=take(signer,off)
digests,off=take(signed);certificates,off=take(signed,off);cert,_=take(certificates);digest_rec,_=take(digests);digest,_=take(digest_rec,4)
sig_rec,_=take(signatures);assert struct.unpack_from('<I',sig_rec)[0]==0x103;sig,_=take(sig_rec,4)
key=serialization.load_der_public_key(pub);assert key.public_numbers()==x509.load_der_x509_certificate(cert).public_key().public_numbers();key.verify(sig,signed,padding.PKCS1v15(),hashes.SHA256())
eocd=bytearray(b[e:]);struct.pack_into('<I',eocd,16,start);chunks=[]
for section in [b[:start],b[cd:e],bytes(eocd)]:
 for i in range(0,len(section),1048576):
  chunk=section[i:i+1048576];chunks.append(hashlib.sha256(b'\xa5'+struct.pack('<I',len(chunk))+chunk).digest())
assert hashlib.sha256(b'\x5a'+struct.pack('<I',len(chunks))+b''.join(chunks)).digest()==digest
with zipfile.ZipFile(sys.argv[1]) as z:
 assert z.testzip() is None
 assert z.read('classes.dex')[:4]==b'dex\n'
 for f in ['assets/index.html','assets/style.css','assets/app.js','AndroidManifest.xml']:assert f in z.namelist()
print('Verified v2 RSA signature, certificate/public key, all signed APK chunks, ZIP CRC and required files.')

with zipfile.ZipFile(sys.argv[1]) as z:
 assert z.getinfo('resources.arsc').compress_type==zipfile.ZIP_STORED,'resources.arsc must be uncompressed'
 for i in z.infolist():
  if i.compress_type==zipfile.ZIP_STORED:
   n,x=struct.unpack_from('<HH',b,i.header_offset+26)
   assert (i.header_offset+30+n+x)%4==0,'Misaligned '+i.filename
print('Android 11+ resource compression and alignment checks passed.')

package vn.nongvu.app;
import android.app.*;import android.os.*;import android.webkit.*;import android.graphics.Color;import android.content.*;
public class MainActivity extends Activity {
 WebView web; Updater updater;
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(231,243,250));getWindow().setNavigationBarColor(Color.rgb(230,239,247));immersive();web=new WebView(this);setContentView(web);updater=new Updater(this);web.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);web.setBackgroundColor(Color.rgb(246,248,244));web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(true);web.getSettings().setAllowContentAccess(false);web.getSettings().setAllowFileAccessFromFileURLs(false);web.getSettings().setAllowUniversalAccessFromFileURLs(false);web.addJavascriptInterface(new Bridge(),"NongVuAndroid");web.setWebViewClient(new WebViewClient(){public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return true;}public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){if(!"file".equals(r.getUrl().getScheme()))return new WebResourceResponse("text/plain","UTF-8",new java.io.ByteArrayInputStream(new byte[0]));return null;}});web.setWebChromeClient(new WebChromeClient(){public boolean onJsConfirm(WebView v,String u,String m,final JsResult r){new AlertDialog.Builder(MainActivity.this).setMessage(m).setPositiveButton("Đồng ý",(d,w)->r.confirm()).setNegativeButton("Hủy",(d,w)->r.cancel()).setOnCancelListener(d->r.cancel()).show();return true;}});Reminders.channel(this);web.loadUrl("file:///android_asset/index.html");updater.guardLoad();updater.check(false);}
 void immersive(){getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|android.view.View.SYSTEM_UI_FLAG_FULLSCREEN|android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}
 @Override public void onWindowFocusChanged(boolean focused){super.onWindowFocusChanged(focused);if(focused)immersive();}
 public void message(String text){runOnUiThread(()->android.widget.Toast.makeText(this,text,android.widget.Toast.LENGTH_LONG).show());}
 @Override protected void onResume(){super.onResume();if(updater!=null)updater.resume();}
 public class Bridge {
 @JavascriptInterface public void setTheme(String value){runOnUiThread(()->{boolean dark="dark".equals(value);getWindow().setStatusBarColor(dark?Color.rgb(19,42,64):Color.rgb(231,243,250));getWindow().setNavigationBarColor(dark?Color.rgb(20,42,64):Color.rgb(230,239,247));immersive();});}
 @JavascriptInterface public String document(){return updater.document();}
 @JavascriptInterface public String updateInfo(){return updater.info();}
 @JavascriptInterface public void updates(){runOnUiThread(()->{if(updater.manifest!=null)updater.showMenu();else updater.check(true);});}
 @JavascriptInterface public void ready(int build){runOnUiThread(()->updater.ready(build));}
 @JavascriptInterface public void schedule(String json){Reminders.replace(MainActivity.this,json);}
 @JavascriptInterface public boolean permitted(){return Build.VERSION.SDK_INT<33||checkSelfPermission("android.permission.POST_NOTIFICATIONS")==0;}
 @JavascriptInterface public void requestPermission(){runOnUiThread(()->{if(Build.VERSION.SDK_INT>=33)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},10);});}
 @JavascriptInterface public void test(){Reminders.show(MainActivity.this,99999,"Nông Vụ · Thử nhắc việc","Thông báo thử đã hoạt động.");}
 }
 @Override public void onBackPressed(){web.evaluateJavascript("(()=>{let d=document.querySelector('dialog[open]');if(d){d.close();return true}return false})()",r->{if(!"true".equals(r))new AlertDialog.Builder(this).setMessage("Đóng Nông Vụ? Lịch nhắc đã bật vẫn được giữ.").setPositiveButton("Đóng",(d,w)->finish()).setNegativeButton("Ở lại",null).show();});}
}

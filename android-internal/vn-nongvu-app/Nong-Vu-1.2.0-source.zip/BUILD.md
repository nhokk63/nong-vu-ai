# Nông Vụ Desktop 1.2.0

APK 10200, built-in UI12000; signed OTA12001 requires APK10200. Same app ID and signing certificate. Cài đè, không gỡ ứng dụng.

Desktop shell: four independent draggable/resizable windows, close/minimize/maximize, restore from dock, menus, per-window filters and persisted geometry. SVG icons/wallpaper are inline: no external/data image dependency. Native fullscreen uses immersive sticky flags and supports orientation changes without Activity recreation. Existing localStorage keys and base URL retained.

Build: tools/build.py with ANDROID_BUILD_TOOLS (ecj.jar, r8.jar, apktool.jar) and ANDROID_API_JAR. Original private signing files must be supplied privately in tools; excluded from source archive.

Validation: compilation, signature/alignment/ZIP checks, matching certificate, JS runtime regression for multi-window lifecycle, filters, save/undo, native-ready, inline icons; browser drag/minimize/restore/maximize and portrait UI. Physical-device fullscreen, installation and touch performance remain untested.

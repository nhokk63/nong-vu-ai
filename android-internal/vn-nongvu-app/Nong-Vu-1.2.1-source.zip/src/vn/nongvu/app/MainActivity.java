package vn.nongvu.app;
import android.app.*;import android.os.*;import android.webkit.*;import android.graphics.Color;import android.content.*;
public class MainActivity extends Activity {
 WebView web; Updater updater;
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(231,243,250));getWindow().setNavigationBarColor(Color.rgb(230,239,247));immersive();web=new WebView(this);setContentView(web);updater=new Updater(this);web.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);web.setBackgroundColor(Color.rgb(246,248,244));web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(true);web.getSettings().setAllowContentAccess(false);web.getSettings().setAllowFileAccessFromFileURLs(false);web.getSettings().setAllowUniversalAccessFromFileURLs(false);web.addJavascriptInterface(new Bridge(),"NongVuAndroid");web.setWebViewClient(new WebViewClient(){public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return true;}public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){if(!"file".equals(r.getUrl().getScheme()))return new WebResourceResponse("text/plain","UTF-8",new java.io.ByteArrayInputStream(new byte[0]));return null;}});web.setWebChromeClient(new WebChromeClient(){public boolean onJsConfirm(WebView v,String u,String m,final JsResult r){new AlertDialog.Builder(MainActivity.this).setMessage(m).setPositiveButton("Đồng ý",(d,w)->r.confirm()).setNegativeButton("Hủy",(d,w)->r.cancel()).setOnCancelListener(d->r.cancel()).show();return true;}});Reminders.channel(this);web.loadUrl("file:///android_asset/index.html");updater.guardLoad();updater.check(false);}
 void immersive(){if(Build.VERSION.SDK_INT>=28){android.view.WindowManager.LayoutParams lp=getWindow().getAttributes();lp.layoutInDisplayCutoutMode=android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;getWindow().setAttributes(lp);}getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|android.view.View.SYSTEM_UI_FLAG_FULLSCREEN|android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}
 @Override public void onWindowFocusChanged(boolean focused){super.onWindowFocusChanged(focused);if(focused)immersive();}
 public void message(String text){runOnUiThread(()->android.widget.Toast.makeText(this,text,android.widget.Toast.LENGTH_LONG).show());}
 @Override protected void onResume(){super.onResume();if(updater!=null)updater.resume();}
 public class Bridge {
 @JavascriptInterface public void chooseWallpaper(){runOnUiThread(()->{try{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,42);}catch(Exception e){message("Không mở được trình chọn ảnh.");}});}

 @JavascriptInterface public void setTheme(String value){runOnUiThread(()->{boolean dark="dark".equals(value);getWindow().setStatusBarColor(dark?Color.rgb(19,42,64):Color.rgb(231,243,250));getWindow().setNavigationBarColor(dark?Color.rgb(20,42,64):Color.rgb(230,239,247));immersive();});}
 @JavascriptInterface public String document(){return updater.document();}
 @JavascriptInterface public String updateInfo(){return updater.info();}
 @JavascriptInterface public void updates(){runOnUiThread(()->{if(updater.manifest!=null)updater.showMenu();else updater.check(true);});}
 @JavascriptInterface public void ready(int build){runOnUiThread(()->updater.ready(build));}
 @JavascriptInterface public void schedule(String json){Reminders.replace(MainActivity.this,json);}
 @JavascriptInterface public boolean permitted(){return Build.VERSION.SDK_INT<33||checkSelfPermission("android.permission.POST_NOTIFICATIONS")==0;}
 @JavascriptInterface public void requestPermission(){runOnUiThread(()->{if(Build.VERSION.SDK_INT>=33)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},10);});}
 @JavascriptInterface public void test(){Reminders.show(MainActivity.this,99999,"Nông Vụ · Thử nhắc việc","Thông báo thử đã hoạt động.");}
 }

 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request!=42||result!=RESULT_OK||data==null||data.getData()==null)return;final android.net.Uri uri=data.getData();new Thread(()->{try{
 android.graphics.BitmapFactory.Options o=new android.graphics.BitmapFactory.Options();o.inJustDecodeBounds=true;
 try(java.io.InputStream in=getContentResolver().openInputStream(uri)){android.graphics.BitmapFactory.decodeStream(in,null,o);}
 if(o.outWidth<=0||o.outHeight<=0)throw new java.io.IOException("Invalid image");
 o.inSampleSize=1;while(Math.max(o.outWidth,o.outHeight)/o.inSampleSize>1600)o.inSampleSize*=2;o.inJustDecodeBounds=false;
 android.graphics.Bitmap bitmap;try(java.io.InputStream in=getContentResolver().openInputStream(uri)){bitmap=android.graphics.BitmapFactory.decodeStream(in,null,o);}if(bitmap==null)throw new java.io.IOException("Invalid bitmap");
 int orientation=1;try(java.io.InputStream in=getContentResolver().openInputStream(uri)){android.media.ExifInterface exif=new android.media.ExifInterface(in);orientation=exif.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION,1);}catch(Exception ignored){}
 android.graphics.Matrix matrix=new android.graphics.Matrix();switch(orientation){case 2:matrix.setScale(-1,1);break;case 3:matrix.setRotate(180);break;case 4:matrix.setScale(1,-1);break;case 5:matrix.setRotate(90);matrix.postScale(-1,1);break;case 6:matrix.setRotate(90);break;case 7:matrix.setRotate(-90);matrix.postScale(-1,1);break;case 8:matrix.setRotate(-90);break;}
 if(!matrix.isIdentity()){android.graphics.Bitmap rotated=android.graphics.Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);if(rotated!=bitmap){bitmap.recycle();bitmap=rotated;}}
 java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG,85,out);bitmap.recycle();final String image="data:image/jpeg;base64,"+android.util.Base64.encodeToString(out.toByteArray(),android.util.Base64.NO_WRAP);
 runOnUiThread(()->{if(!isFinishing())web.evaluateJavascript("window.nongvuWallpaperReceived && window.nongvuWallpaperReceived("+org.json.JSONObject.quote(image)+")",null);});
 }catch(Exception|OutOfMemoryError error){runOnUiThread(()->{if(!isFinishing())web.evaluateJavascript("window.nongvuWallpaperError && window.nongvuWallpaperError()",null);});}}).start();}
 @Override public void onBackPressed(){web.evaluateJavascript("(()=>{let d=document.querySelector('dialog[open]');if(d){d.close();return true}return false})()",r->{if(!"true".equals(r))new AlertDialog.Builder(this).setMessage("Đóng Nông Vụ? Lịch nhắc đã bật vẫn được giữ.").setPositiveButton("Đóng",(d,w)->finish()).setNegativeButton("Ở lại",null).show();});}
}

Nông Vụ 1.2.1 — X-UI wallpaper and edge-to-edge desktop

APK 10201, built-in UI 12010; OTA 12011 requires APK 10201 for native image selection.
Maximized windows start at the measured menu bottom and fill the viewport. Dock overlays windows; content has scroll padding to keep last rows reachable. Finder uses folder rows.
Wallpaper: native ACTION_OPEN_DOCUMENT, sampled Bitmap decode <=1600px, EXIF orientation, JPEG bridge to WebView; JS resizes <=1440px, samples color, stores normalized image and hue locally. No storage permission or remote image upload. Cancel leaves existing wallpaper unchanged. Presets and sync toggle supported in light/dark themes.
Build with ANDROID_BUILD_TOOLS and ANDROID_API_JAR, using original private signing key/cert supplied outside source archive.
Validation: JS runtime tests (window lifecycle, task data, full-screen geometry portrait/landscape, hue extraction, persistence and sync modes); browser UI checks (maximize, dock overlay, wallpaper selection, image decoding); native compile and APK v2 verification. No physical Android or emulator testing available.
